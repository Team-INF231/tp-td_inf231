#ifndef __MATRICE__H__
#define __MATRICE__H__



	#include<stdio.h>
	#include<stdlib.h>
	#define max 100

	//static int max=100;
	
	//fonction pour effectue la somme
	void  lire_matrice(int matrice[max][max],int lignes,int colonnes);
	void afficher_matrice(int matrice[max][max], int lignes, int colonnes);



#endif